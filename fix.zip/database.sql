#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/Users/Administrator/Desktop/Jigsaw/database.mdb
#   sourceusername=root
#   sourcepassword=** HIDDEN **
#   sourcesystemdatabase=
#   destinationdatabase=movedb
#   storageengine=MyISAM
#   dropdatabase=0
#   createtables=1
#   unicode=1
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=1
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `movedb`;
USE `movedb`;

#
# Table structure for table 'billdata'
#

DROP TABLE IF EXISTS `billdata`;

CREATE TABLE `billdata` (
  `Bid` VARCHAR(3) NOT NULL, 
  `Bdata` VARCHAR(200), 
  INDEX (`Bid`), 
  PRIMARY KEY (`Bid`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'billdata'
#

INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('001', 'ค่าบริการซ่อมโทรศัพท์มือถือ');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('002', 'ค่าบริการลงโปรแกรมโทรศัพท์มือถือ');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('003', 'เปลี่ยนข้อความรายการที่ 3');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('004', 'เปลี่ยนข้อความรายการที่ 4');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('005', 'เปลี่ยนข้อความรายการที่ 5');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('006', 'เปลี่ยนข้อความรายการที่ 6');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('007', 'เปลี่ยนข้อความรายการที่ 7');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('008', 'เปลี่ยนข้อความรายการที่ 8');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('009', 'เปลี่ยนข้อความรายการที่ 9');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('010', 'เปลี่ยนข้อความรายการที่ 10');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('011', 'เปลี่ยนข้อความรายการที่ 11');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('012', 'เปลี่ยนข้อความรายการที่ 12');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('013', 'เปลี่ยนข้อความรายการที่ 13');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('014', 'เปลี่ยนข้อความรายการที่ 14');
INSERT INTO `billdata` (`Bid`, `Bdata`) VALUES ('015', 'เปลี่ยนข้อความรายการที่ 15');
# 15 records

#
# Table structure for table 'brand'
#

DROP TABLE IF EXISTS `brand`;

CREATE TABLE `brand` (
  `brand_id` VARCHAR(4) NOT NULL, 
  `brand_name` VARCHAR(30), 
  `pro_grp` VARCHAR(4), 
  PRIMARY KEY (`brand_id`), 
  INDEX (`brand_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'brand'
#

INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0001', 'iPhone', '0001');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0002', 'Samsung', '0001');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0003', 'Asus', '0001');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0004', 'Oppo', '0001');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0005', 'Asus', '0002');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0006', 'Acer', '0002');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0007', 'Samsung', '0002');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0008', 'HP', '0002');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0009', 'Dell', '0002');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0010', 'Lenovo', '0002');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0011', 'Lenovo', '0003');
INSERT INTO `brand` (`brand_id`, `brand_name`, `pro_grp`) VALUES ('0012', 'HP', '0004');
# 12 records

#
# Table structure for table 'company'
#

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `cid` VARCHAR(5) NOT NULL, 
  `cname` VARCHAR(80), 
  `ccontact` VARCHAR(50), 
  `caddress` VARCHAR(100), 
  `ctel` VARCHAR(40), 
  `cfax` VARCHAR(40), 
  `cweb` VARCHAR(50), 
  `cemail` VARCHAR(50), 
  INDEX (`cid`), 
  PRIMARY KEY (`cid`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'company'
#

INSERT INTO `company` (`cid`, `cname`, `ccontact`, `caddress`, `ctel`, `cfax`, `cweb`, `cemail`) VALUES ('00001', 'Dcomputer', '', '209/1-2 ถ.สรรพาวุธ แขวงบางนา เขตบางนา กรุงเทพฯ 10260', '(02) 398-0800', '(02) 393-5585', 'http://www.dcom.co.th', 'info@dcom.co.th');
INSERT INTO `company` (`cid`, `cname`, `ccontact`, `caddress`, `ctel`, `cfax`, `cweb`, `cemail`) VALUES ('00002', 'Synnex Co,.Ltd.', '', '433 ถนนสุคนธสวัสดิ์ แขวง ลาดพร้าว เขต ลาดพร้าว กรุงเทพฯ 10230', '66(0) 2553 8888', '66(0) 2553-8877', 'http://www.synnex.co.th', '');
# 2 records

#
# Table structure for table 'customer'
#

DROP TABLE IF EXISTS `customer`;

CREATE TABLE `customer` (
  `cus_id` VARCHAR(6) NOT NULL, 
  `cus_name` VARCHAR(80), 
  `cus_address` VARCHAR(100), 
  `cus_tel` VARCHAR(40), 
  `cus_fax` VARCHAR(40), 
  `cus_email` VARCHAR(50), 
  `cus_tax_id` VARCHAR(25), 
  `cus_officehead` VARCHAR(1), 
  `cus_officebranch` VARCHAR(5), 
  INDEX (`cus_id`), 
  PRIMARY KEY (`cus_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'customer'
#

INSERT INTO `customer` (`cus_id`, `cus_name`, `cus_address`, `cus_tel`, `cus_fax`, `cus_email`, `cus_tax_id`, `cus_officehead`, `cus_officebranch`) VALUES ('000001', 'รพสต.บ้านเนินโมก', '-', '-', '-', '-', '', '0', '');
# 1 records

#
# Table structure for table 'databill'
#

DROP TABLE IF EXISTS `databill`;

CREATE TABLE `databill` (
  `Frun_id` VARCHAR(13), 
  `b_type` VARCHAR(30), 
  `b_name` VARCHAR(80), 
  `Bqty` VARCHAR(10), 
  `Bprice` VARCHAR(10), 
  `Bamount` VARCHAR(10), 
  `Bdis` VARCHAR(10), 
  `Bvat` VARCHAR(5), 
  `Buser` VARCHAR(30), 
  `Bdate` DATETIME, 
  `Btime` VARCHAR(8), 
  `Bcostpart` VARCHAR(10), 
  INDEX (`Frun_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'databill'
#

# 0 records

#
# Table structure for table 'dataclaim'
#

DROP TABLE IF EXISTS `dataclaim`;

CREATE TABLE `dataclaim` (
  `Frun_id` VARCHAR(13) NOT NULL, 
  `Cstatus` VARCHAR(1), 
  `cid` VARCHAR(5), 
  `Csend_date` DATETIME, 
  `Ctran_send_by` VARCHAR(50), 
  `Csup_no` VARCHAR(30), 
  `Csend_part` VARCHAR(100), 
  `Ccomment` VARCHAR(200), 
  `Cuser_send` VARCHAR(30), 
  `Cdate_send` VARCHAR(20), 
  `Ctime_send` VARCHAR(8), 
  `Ctran_no` VARCHAR(30), 
  `Creceive_date` DATETIME, 
  `Ctran_receive_by` VARCHAR(50), 
  `Cfully_miss` VARCHAR(1), 
  `Cmiss_comment` VARCHAR(100), 
  `Csn_old_new` VARCHAR(1), 
  `Csn_new_comment` VARCHAR(40), 
  `Csn_re_comment` VARCHAR(40), 
  `Ccomment_rec` VARCHAR(200), 
  `Cuser_receive` VARCHAR(30), 
  `Cdate` VARCHAR(20), 
  `Ctime` VARCHAR(8), 
  INDEX (`cid`), 
  INDEX (`Frun_id`), 
  PRIMARY KEY (`Frun_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'dataclaim'
#

# 0 records

#
# Table structure for table 'datacus'
#

DROP TABLE IF EXISTS `datacus`;

CREATE TABLE `datacus` (
  `Frun_id` VARCHAR(13) NOT NULL, 
  `dtp_receive` DATETIME, 
  `Ftime_receive` VARCHAR(8), 
  `Fuser` VARCHAR(30), 
  `Ftechnician` VARCHAR(30), 
  `cus_id` VARCHAR(6), 
  `Fcontact_name` VARCHAR(50), 
  `pro_id` VARCHAR(4), 
  `brand_id` VARCHAR(4), 
  `model_id` VARCHAR(4), 
  `Fcolor` VARCHAR(10), 
  `Fsn` VARCHAR(40), 
  `Fimei` VARCHAR(40), 
  `Fvoid` VARCHAR(30), 
  `Fvoidexp` VARCHAR(8), 
  `dm_id` VARCHAR(50), 
  `Fscar` VARCHAR(80), 
  `Flost` VARCHAR(120), 
  `Fcomment` VARCHAR(180), 
  `C1` VARCHAR(1), 
  `C2` VARCHAR(1), 
  `C3` VARCHAR(1), 
  `C4` VARCHAR(1), 
  `C5` VARCHAR(1), 
  `C6` VARCHAR(1), 
  `C7` VARCHAR(1), 
  `C8` VARCHAR(1), 
  `C9` VARCHAR(1), 
  `Fmemsize` VARCHAR(8), 
  `Fother` VARCHAR(30), 
  `Fabout` DECIMAL(19,4) DEFAULT 0, 
  `dtp_givedate` DATETIME, 
  `Fvoidshop` INTEGER DEFAULT 0, 
  `dtp_voidshopexp` DATETIME, 
  `Sname_status` VARCHAR(20), 
  `Sdate` DATETIME, 
  INDEX (`brand_id`), 
  INDEX (`cus_id`), 
  INDEX (`Frun_id`), 
  INDEX (`model_id`), 
  PRIMARY KEY (`Frun_id`), 
  INDEX (`pro_id`), 
  INDEX (`Fvoid`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'datacus'
#

INSERT INTO `datacus` (`Frun_id`, `dtp_receive`, `Ftime_receive`, `Fuser`, `Ftechnician`, `cus_id`, `Fcontact_name`, `pro_id`, `brand_id`, `model_id`, `Fcolor`, `Fsn`, `Fimei`, `Fvoid`, `Fvoidexp`, `dm_id`, `Fscar`, `Flost`, `Fcomment`, `C1`, `C2`, `C3`, `C4`, `C5`, `C6`, `C7`, `C8`, `C9`, `Fmemsize`, `Fother`, `Fabout`, `dtp_givedate`, `Fvoidshop`, `dtp_voidshopexp`, `Sname_status`, `Sdate`) VALUES ('SA6308-000001', '2020-08-04 00:00:00', '14:43', 'Administrator', 'Administrator', '', '', '0004', '0012', '0010', 'ขาว', '00002939', '', '', '/', '001', '-', 'พอร์ต USB หลวม', '', '0', '1', '0', '0', '0', '0', '0', '0', '0', '', '', 0, '2020-08-04 00:00:00', 0, NULL, 'รอซ่อม', NULL);
INSERT INTO `datacus` (`Frun_id`, `dtp_receive`, `Ftime_receive`, `Fuser`, `Ftechnician`, `cus_id`, `Fcontact_name`, `pro_id`, `brand_id`, `model_id`, `Fcolor`, `Fsn`, `Fimei`, `Fvoid`, `Fvoidexp`, `dm_id`, `Fscar`, `Flost`, `Fcomment`, `C1`, `C2`, `C3`, `C4`, `C5`, `C6`, `C7`, `C8`, `C9`, `Fmemsize`, `Fother`, `Fabout`, `dtp_givedate`, `Fvoidshop`, `dtp_voidshopexp`, `Sname_status`, `Sdate`) VALUES ('SA6308-000002', '2020-08-05 00:00:00', '15:25', 'Administrator', 'กุ้ง', '000001', '', '0004', '0012', '0010', '', '00002902', '', 'หมดประกัน', '/', '001', '', 'USB หลวม', '', '0', '0', '0', '1', '0', '0', '0', '0', '0', '', '', 0, '2020-08-04 00:00:00', 0, NULL, 'รอซ่อม', '2020-08-05 00:00:00');
INSERT INTO `datacus` (`Frun_id`, `dtp_receive`, `Ftime_receive`, `Fuser`, `Ftechnician`, `cus_id`, `Fcontact_name`, `pro_id`, `brand_id`, `model_id`, `Fcolor`, `Fsn`, `Fimei`, `Fvoid`, `Fvoidexp`, `dm_id`, `Fscar`, `Flost`, `Fcomment`, `C1`, `C2`, `C3`, `C4`, `C5`, `C6`, `C7`, `C8`, `C9`, `Fmemsize`, `Fother`, `Fabout`, `dtp_givedate`, `Fvoidshop`, `dtp_voidshopexp`, `Sname_status`, `Sdate`) VALUES ('SA6308-000003', '2020-08-04 00:00:00', '15:25', 'Administrator', 'กุ้ง', '000001', '', '0004', '0012', '0010', '', '00002902', '', 'หมดประกัน', '/', '001', '', 'USB หลวม', '', '0', '0', '0', '1', '0', '0', '0', '0', '0', '', '', 0, '2020-08-04 00:00:00', 0, NULL, 'คืนสินค้าแล้ว', '2020-08-05 00:00:00');
INSERT INTO `datacus` (`Frun_id`, `dtp_receive`, `Ftime_receive`, `Fuser`, `Ftechnician`, `cus_id`, `Fcontact_name`, `pro_id`, `brand_id`, `model_id`, `Fcolor`, `Fsn`, `Fimei`, `Fvoid`, `Fvoidexp`, `dm_id`, `Fscar`, `Flost`, `Fcomment`, `C1`, `C2`, `C3`, `C4`, `C5`, `C6`, `C7`, `C8`, `C9`, `Fmemsize`, `Fother`, `Fabout`, `dtp_givedate`, `Fvoidshop`, `dtp_voidshopexp`, `Sname_status`, `Sdate`) VALUES ('SA6308-000004', '2020-08-06 00:00:00', '16:20', 'Administrator', 'Administrator', '000001', '', '0004', '0012', '0010', '', '00002902', '', '', '/', '001', '', '', '', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '', 0, '2020-08-06 00:00:00', 0, NULL, 'รอซ่อม', NULL);
INSERT INTO `datacus` (`Frun_id`, `dtp_receive`, `Ftime_receive`, `Fuser`, `Ftechnician`, `cus_id`, `Fcontact_name`, `pro_id`, `brand_id`, `model_id`, `Fcolor`, `Fsn`, `Fimei`, `Fvoid`, `Fvoidexp`, `dm_id`, `Fscar`, `Flost`, `Fcomment`, `C1`, `C2`, `C3`, `C4`, `C5`, `C6`, `C7`, `C8`, `C9`, `Fmemsize`, `Fother`, `Fabout`, `dtp_givedate`, `Fvoidshop`, `dtp_voidshopexp`, `Sname_status`, `Sdate`) VALUES ('SA6406-000005', '2021-06-07 00:00:00', '15:15', 'Administrator', 'กุ้ง', '000001', '', '0002', '0006', '0009', '', '11111', '', '', '/', '002', '', 'xxx', 'xxx', '0', '0', '0', '0', '0', '0', '0', '0', '0', '', '', 0, '2021-06-07 00:00:00', 0, NULL, 'ซ่อมเสร็จแล้ว', '2021-06-07 00:00:00');
# 5 records

#
# Table structure for table 'dataman'
#

DROP TABLE IF EXISTS `dataman`;

CREATE TABLE `dataman` (
  `dm_id` VARCHAR(3) NOT NULL, 
  `dm_name` VARCHAR(60), 
  PRIMARY KEY (`dm_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'dataman'
#

INSERT INTO `dataman` (`dm_id`, `dm_name`) VALUES ('001', '-');
INSERT INTO `dataman` (`dm_id`, `dm_name`) VALUES ('002', 'เก็บข้อมูลไดรว์ C และ Desktop');
INSERT INTO `dataman` (`dm_id`, `dm_name`) VALUES ('003', 'เก็บข้อมูลทั้งหมด');
INSERT INTO `dataman` (`dm_id`, `dm_name`) VALUES ('004', 'ลบข้อมูลทั้งหมดได้');
# 4 records

#
# Table structure for table 'dataqu'
#

DROP TABLE IF EXISTS `dataqu`;

CREATE TABLE `dataqu` (
  `Frun_id` VARCHAR(13), 
  `b_type` VARCHAR(30), 
  `b_name` VARCHAR(80), 
  `Qqty` VARCHAR(10), 
  `Qprice` VARCHAR(10), 
  `Qamount` VARCHAR(10), 
  `Qdis` VARCHAR(10), 
  `Qvat` VARCHAR(5), 
  `Quser` VARCHAR(30), 
  `Qdate` VARCHAR(20), 
  `Qtime` VARCHAR(8), 
  `Qby` VARCHAR(50), 
  `Qcostpart` VARCHAR(10), 
  INDEX (`Frun_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'dataqu'
#

# 0 records

#
# Table structure for table 'datashop'
#

DROP TABLE IF EXISTS `datashop`;

CREATE TABLE `datashop` (
  `sh_name` VARCHAR(80), 
  `sh_owner` VARCHAR(50), 
  `sh_regis` VARCHAR(25), 
  `sh_vat_no` VARCHAR(30), 
  `sh_address` VARCHAR(100), 
  `sh_tel` VARCHAR(40), 
  `sh_fax` VARCHAR(40), 
  `sh_website` VARCHAR(50), 
  `sh_email` VARCHAR(50), 
  `sh_vat_rate` DECIMAL(19,4) DEFAULT 0, 
  `sh_copy_type` VARCHAR(1), 
  `c1` VARCHAR(20), 
  `c2` VARCHAR(20), 
  `c3` VARCHAR(20), 
  `c4` VARCHAR(20), 
  `c5` VARCHAR(20), 
  `c6` VARCHAR(20), 
  `c7` VARCHAR(20), 
  `c8` VARCHAR(20), 
  `c9` VARCHAR(20)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'datashop'
#

INSERT INTO `datashop` (`sh_name`, `sh_owner`, `sh_regis`, `sh_vat_no`, `sh_address`, `sh_tel`, `sh_fax`, `sh_website`, `sh_email`, `sh_vat_rate`, `sh_copy_type`, `c1`, `c2`, `c3`, `c4`, `c5`, `c6`, `c7`, `c8`, `c9`) VALUES ('บริษัท ฟอร์ยูออลล์ จำกัด', 'ชยาวิชญ์ ชะนะ', '-', '-', '102/1 หมู่4 ต.บ่อกวางทอง อ.บ่อทอง จ.ชลบุรี 20270 (สำนักงานใหญ่)', ',080-7721144', '-', '-', '-', 7, '1', 'สาย AC', 'สาย Data link', 'เมาส์', 'สาย USB', 'กระเป๋า', 'Bluetooth', 'Adaptor', 'อื่นๆ', 'Memory Card');
# 1 records

#
# Table structure for table 'groupcus'
#

DROP TABLE IF EXISTS `groupcus`;

CREATE TABLE `groupcus` (
  `grp_id` VARCHAR(3) NOT NULL, 
  `grp_name` VARCHAR(100), 
  PRIMARY KEY (`grp_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'groupcus'
#

# 0 records

#
# Table structure for table 'groupproduct'
#

DROP TABLE IF EXISTS `groupproduct`;

CREATE TABLE `groupproduct` (
  `grp_id` VARCHAR(10) NOT NULL, 
  `grp_name` VARCHAR(100), 
  PRIMARY KEY (`grp_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'groupproduct'
#

# 0 records

#
# Table structure for table 'headbill'
#

DROP TABLE IF EXISTS `headbill`;

CREATE TABLE `headbill` (
  `Bill_fix` VARCHAR(6), 
  `Bill_cash` VARCHAR(6), 
  `Bill_qu` VARCHAR(6), 
  `Bill_cl` VARCHAR(6)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'headbill'
#

INSERT INTO `headbill` (`Bill_fix`, `Bill_cash`, `Bill_qu`, `Bill_cl`) VALUES ('SA', 'BL', 'QU', 'CL');
# 1 records

#
# Table structure for table 'listbill'
#

DROP TABLE IF EXISTS `listbill`;

CREATE TABLE `listbill` (
  `b_id` VARCHAR(4) NOT NULL, 
  `b_type` VARCHAR(30), 
  `b_name` VARCHAR(80), 
  `b_price` DECIMAL(19,4) DEFAULT 0, 
  `b_costpart` DOUBLE NULL, 
  INDEX (`b_id`), 
  PRIMARY KEY (`b_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'listbill'
#

INSERT INTO `listbill` (`b_id`, `b_type`, `b_name`, `b_price`, `b_costpart`) VALUES ('0001', 'ค่าบริการ', 'สแกนไวรัส', 200, NULL);
# 1 records

#
# Table structure for table 'listbilltype'
#

DROP TABLE IF EXISTS `listbilltype`;

CREATE TABLE `listbilltype` (
  `bt_id` VARCHAR(3) NOT NULL, 
  `bt_name` VARCHAR(50), 
  INDEX (`bt_id`), 
  PRIMARY KEY (`bt_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'listbilltype'
#

INSERT INTO `listbilltype` (`bt_id`, `bt_name`) VALUES ('001', 'ค่าบริการ');
INSERT INTO `listbilltype` (`bt_id`, `bt_name`) VALUES ('002', 'ค่าอะไหล่');
INSERT INTO `listbilltype` (`bt_id`, `bt_name`) VALUES ('003', 'ค่าบริการ(นอกสถานที่)');
# 3 records

#
# Table structure for table 'log'
#

DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `log_id` VARCHAR(10) NOT NULL, 
  `log_name` VARCHAR(30), 
  `log_datein` DATETIME, 
  `log_timein` VARCHAR(10), 
  `log_dateout` DATETIME, 
  `log_timeout` VARCHAR(10), 
  PRIMARY KEY (`log_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'log'
#

# 0 records

#
# Table structure for table 'login'
#

DROP TABLE IF EXISTS `login`;

CREATE TABLE `login` (
  `login_id` VARCHAR(15) NOT NULL, 
  `login_name` VARCHAR(30), 
  `login_password` VARCHAR(15) NOT NULL, 
  `emp_idcard` VARCHAR(13), 
  `pos_id` VARCHAR(3), 
  `emp_address` VARCHAR(100), 
  `emp_tel` VARCHAR(40), 
  `emp_email` VARCHAR(50), 
  `cu1` VARCHAR(1), 
  `cu2` VARCHAR(1), 
  `cu3` VARCHAR(1), 
  `cu4` VARCHAR(1), 
  `cu5` VARCHAR(1), 
  `cu6` VARCHAR(1), 
  `cu7` VARCHAR(1), 
  `cu8` VARCHAR(1), 
  `cu9` VARCHAR(1), 
  `cu10` VARCHAR(1), 
  `cu11` VARCHAR(1), 
  `cu12` VARCHAR(1), 
  `cu13` VARCHAR(1), 
  `cu14` VARCHAR(1), 
  `cu15` VARCHAR(1), 
  `cu16` VARCHAR(1), 
  PRIMARY KEY (`login_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'login'
#

INSERT INTO `login` (`login_id`, `login_name`, `login_password`, `emp_idcard`, `pos_id`, `emp_address`, `emp_tel`, `emp_email`, `cu1`, `cu2`, `cu3`, `cu4`, `cu5`, `cu6`, `cu7`, `cu8`, `cu9`, `cu10`, `cu11`, `cu12`, `cu13`, `cu14`, `cu15`, `cu16`) VALUES ('admin', 'Administrator', '123', '1900900099999', '001', '99/3 หมู่ที่ 3 ต.หาดใหญ่ อ.หาดใหญ่ จ.สงขลา 90110', '0824367872', 'mylife13@windowslive.com', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0');
INSERT INTO `login` (`login_id`, `login_name`, `login_password`, `emp_idcard`, `pos_id`, `emp_address`, `emp_tel`, `emp_email`, `cu1`, `cu2`, `cu3`, `cu4`, `cu5`, `cu6`, `cu7`, `cu8`, `cu9`, `cu10`, `cu11`, `cu12`, `cu13`, `cu14`, `cu15`, `cu16`) VALUES ('010', 'กุ้ง', '12345', '1234567890123', '001', '', '0868992562', '-', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '0');
# 2 records

#
# Table structure for table 'lost'
#

DROP TABLE IF EXISTS `lost`;

CREATE TABLE `lost` (
  `lost_id` VARCHAR(3) NOT NULL, 
  `lost_name` VARCHAR(120), 
  INDEX (`lost_id`), 
  PRIMARY KEY (`lost_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'lost'
#

INSERT INTO `lost` (`lost_id`, `lost_name`) VALUES ('001', 'เปิดไม่ติด');
INSERT INTO `lost` (`lost_id`, `lost_name`) VALUES ('002', 'จอแตก');
INSERT INTO `lost` (`lost_id`, `lost_name`) VALUES ('003', 'ตกน้ำ');
INSERT INTO `lost` (`lost_id`, `lost_name`) VALUES ('004', 'ติดไวรัส');
# 4 records

#
# Table structure for table 'member'
#

DROP TABLE IF EXISTS `member`;

CREATE TABLE `member` (
  `member_id` VARCHAR(10) NOT NULL, 
  `member_idcode` VARCHAR(13), 
  `member_name` VARCHAR(100), 
  `member_shop` VARCHAR(100), 
  `member_address` VARCHAR(100), 
  `member_tel` VARCHAR(30), 
  `member_fax` VARCHAR(20), 
  `member_email` VARCHAR(30), 
  INDEX (`member_id`), 
  PRIMARY KEY (`member_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'member'
#

INSERT INTO `member` (`member_id`, `member_idcode`, `member_name`, `member_shop`, `member_address`, `member_tel`, `member_fax`, `member_email`) VALUES ('00000', '0000000000000', 'เงินสด', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `member` (`member_id`, `member_idcode`, `member_name`, `member_shop`, `member_address`, `member_tel`, `member_fax`, `member_email`) VALUES ('00001', '', 'สรศักดิ์  ช่วยแก้ว', 'เอสเอ คอมพิวเตอร์', 'หาดใหญ่ สงขลา', '082-4367872', '074-384255', 'mylife13@windowslive.com');
# 2 records

#
# Table structure for table 'model'
#

DROP TABLE IF EXISTS `model`;

CREATE TABLE `model` (
  `model_id` VARCHAR(4) NOT NULL, 
  `model_name` VARCHAR(30), 
  `brand_grp` VARCHAR(4), 
  PRIMARY KEY (`model_id`), 
  INDEX (`model_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'model'
#

INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0001', 'iPhone 6S', '0001');
INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0002', 'iPhone 6S Plus', '0001');
INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0003', 'iPhone 7', '0001');
INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0004', 'iPhone 7 Plus', '0001');
INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0005', 'Asus Zenbook UX330UA', '0005');
INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0006', 'Asus Zenbook UX410UQ', '0005');
INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0007', 'LENOVO YOGA TABLET3', '0011');
INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0008', 'Acer Swift SF314', '0006');
INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0009', 'Acer Aspire VX5', '0006');
INSERT INTO `model` (`model_id`, `model_name`, `brand_grp`) VALUES ('0010', 'LaserJet 1102', '0012');
# 10 records

#
# Table structure for table 'pos'
#

DROP TABLE IF EXISTS `pos`;

CREATE TABLE `pos` (
  `pos_id` VARCHAR(3) NOT NULL, 
  `pos_name` VARCHAR(50), 
  INDEX (`pos_id`), 
  PRIMARY KEY (`pos_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'pos'
#

INSERT INTO `pos` (`pos_id`, `pos_name`) VALUES ('001', 'ผู้ดูแลระบบ');
INSERT INTO `pos` (`pos_id`, `pos_name`) VALUES ('002', 'บัญชีและการเงิน');
INSERT INTO `pos` (`pos_id`, `pos_name`) VALUES ('003', 'ช่างเทคนิค');
# 3 records

#
# Table structure for table 'product'
#

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `pro_date` DATETIME, 
  `pro_code` VARCHAR(25) NOT NULL, 
  `grp_id` VARCHAR(10), 
  `pro_name` VARCHAR(60), 
  `pro_qty` INTEGER, 
  `pro_type` VARCHAR(30), 
  `pro_price_sale` DECIMAL(19,4) DEFAULT 0, 
  `pro_price_cost` DECIMAL(19,4) DEFAULT 0, 
  PRIMARY KEY (`pro_code`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'product'
#

# 0 records

#
# Table structure for table 'productfix'
#

DROP TABLE IF EXISTS `productfix`;

CREATE TABLE `productfix` (
  `pro_id` VARCHAR(4) NOT NULL, 
  `pro_name` VARCHAR(30), 
  PRIMARY KEY (`pro_id`), 
  INDEX (`pro_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'productfix'
#

INSERT INTO `productfix` (`pro_id`, `pro_name`) VALUES ('0001', 'โทรศัพท์มือถือ');
INSERT INTO `productfix` (`pro_id`, `pro_name`) VALUES ('0002', 'Notebook');
INSERT INTO `productfix` (`pro_id`, `pro_name`) VALUES ('0003', 'Tablet');
INSERT INTO `productfix` (`pro_id`, `pro_name`) VALUES ('0004', 'Printer');
# 4 records

#
# Table structure for table 'quotation'
#

DROP TABLE IF EXISTS `quotation`;

CREATE TABLE `quotation` (
  `Qid` VARCHAR(6), 
  `Qdate` DATETIME, 
  `Qadd1` VARCHAR(60), 
  `Qadd2` VARCHAR(60), 
  `Qadd3` VARCHAR(60), 
  `Qto` VARCHAR(100), 
  `Qname` VARCHAR(50), 
  `Qshopname` VARCHAR(100), 
  `Qregis` VARCHAR(25), 
  `Qvatno` VARCHAR(25), 
  `Qaddress` VARCHAR(100), 
  `Qtel` VARCHAR(35), 
  `Q1` VARCHAR(3), 
  `Q2` VARCHAR(70), 
  `Q3` VARCHAR(10), 
  `Q4` VARCHAR(15), 
  `Q5` DECIMAL(19,4) DEFAULT 0, 
  `Q6` DECIMAL(19,4) DEFAULT 0, 
  `Qsum_sale` DECIMAL(19,4) DEFAULT 0, 
  `Qvat` VARCHAR(50), 
  `Qsumvat` DECIMAL(19,4) DEFAULT 0, 
  `Qtotal` DECIMAL(19,4) DEFAULT 0, 
  `Qthaibaht` VARCHAR(85), 
  `Qlife` INTEGER DEFAULT 0, 
  `Qsubmit` INTEGER DEFAULT 0, 
  `Qremark` VARCHAR(150), 
  `Qsign` VARCHAR(50), 
  `Qpos` VARCHAR(80), 
  INDEX (`Qid`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'quotation'
#

# 0 records

#
# Table structure for table 'remark'
#

DROP TABLE IF EXISTS `remark`;

CREATE TABLE `remark` (
  `re_id` VARCHAR(3) NOT NULL, 
  `refix1` VARCHAR(150), 
  `refix2` VARCHAR(150), 
  `refix3` VARCHAR(150), 
  `regive1` VARCHAR(150), 
  `regive2` VARCHAR(150), 
  `regive3` VARCHAR(150), 
  `recl1` VARCHAR(150), 
  `recl2` VARCHAR(150), 
  `recl3` VARCHAR(150), 
  `req1` VARCHAR(100), 
  `req2` VARCHAR(100), 
  `reb1` VARCHAR(100), 
  `reb2` VARCHAR(100), 
  PRIMARY KEY (`re_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'remark'
#

INSERT INTO `remark` (`re_id`, `refix1`, `refix2`, `refix3`, `regive1`, `regive2`, `regive3`, `recl1`, `recl2`, `recl3`, `req1`, `req2`, `reb1`, `reb2`) VALUES ('001', 'หมายเหตุ : ทางร้านจะคืนสินค้าให้แก่ผู้ที่นำเอกสารนี้มารับเครื่องเท่านั้น เมื่อไม่มีการติดต่อกลับจากลูกค้าหลังได้รับจากทางร้าน', '                นานเกิน 45 วัน หรือเบอร์โทรศัพท์ที่ให้ไว้ไม่สามารถติดต่อได้นานเกิน 60 วัน ทางร้านจะไม่รับผิดชอบใดๆทั้งสิ้น', '', 'หมายเหตุ : 1. การรับประกันการซ่อมสินค้าจะมีผลเมื่อมีเอกสารฉบับนี้มายืนยันกับทางร้านเท่านั้น', '                2. เมื่อสินค้าได้รับการซ่อมหรือแก้ไขโดยมิใช่การดำเนินการของทางร้าน ถือว่าการรับประกันสิ้นสุดทันที', '                3. ไม่รับประกันกรณีมีการใช้งานผิดประเภท', '- เมื่อสินค้าได้รับการซ่อมหรือเคลมเสร็จเรียบร้อยแล้ว ทางร้านจะโทรศัพท์แจ้งให้ลูกค้าทราบเพื่อมารับสินค้าคืน', '- หากลูกค้าไม่มารับสินค้าภายใน 15 วันหลังจากแจ้งให้มารับสินค้า หากสินค้าเสียหายทางร้านจะไม่รับผิดชอบ', '', 'ยืนราคาที่ 30 วัน', 'ชำระเป็นเงินสดเท่านั้น', 'รับประกันจะสิ้นสุดลงเมื่อมีการแก้ไขหรือเปลี่ยนแปลงหลังการซ่อมที่มิใช่การดำเนินการของร้าน', '');
# 1 records

#
# Table structure for table 'remark2'
#

DROP TABLE IF EXISTS `remark2`;

CREATE TABLE `remark2` (
  `Frun_id` VARCHAR(13), 
  `req1` VARCHAR(100), 
  `req2` VARCHAR(100)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'remark2'
#

# 0 records

#
# Table structure for table 'remark3'
#

DROP TABLE IF EXISTS `remark3`;

CREATE TABLE `remark3` (
  `Frun_id` VARCHAR(13), 
  `reb1` VARCHAR(100), 
  `reb2` VARCHAR(100)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'remark3'
#

# 0 records

#
# Table structure for table 'sale'
#

DROP TABLE IF EXISTS `sale`;

CREATE TABLE `sale` (
  `run_id` VARCHAR(10), 
  `member_id` VARCHAR(10), 
  `pro_date` DATETIME, 
  `pro_code` VARCHAR(50), 
  `pro_grp` VARCHAR(50), 
  `pro_name` VARCHAR(60), 
  `pro_qty` INTEGER DEFAULT 0, 
  `pro_type` VARCHAR(50), 
  `pro_unit` DECIMAL(19,4) DEFAULT 0, 
  `pro_discount` DECIMAL(19,4) DEFAULT 0, 
  `pro_price` DECIMAL(19,4) DEFAULT 0, 
  `vat_type` VARCHAR(1), 
  `vat_ratio` DECIMAL(19,4) DEFAULT 0, 
  `vat_less` DECIMAL(19,4) DEFAULT 0, 
  `vat_cost` DECIMAL(19,4) DEFAULT 0, 
  `pro_sum` DECIMAL(19,4) DEFAULT 0, 
  `price_cost` DECIMAL(19,4) DEFAULT 0, 
  `price_cost_sum` DECIMAL(19,4) DEFAULT 0, 
  `price_cost_sum_total` DECIMAL(19,4) DEFAULT 0, 
  `sale_name` VARCHAR(25), 
  `sale_time` VARCHAR(10), 
  `sale_pay` VARCHAR(15), 
  `pay_date` DATETIME, 
  INDEX (`member_id`), 
  INDEX (`pro_code`), 
  INDEX (`run_id`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'sale'
#

# 0 records

#
# Table structure for table 'setting'
#

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `rgb11` VARCHAR(3), 
  `rgb12` VARCHAR(3), 
  `rgb13` VARCHAR(3), 
  `rgb21` VARCHAR(3), 
  `rgb22` VARCHAR(3), 
  `rgb23` VARCHAR(3), 
  `rgb31` VARCHAR(3), 
  `rgb32` VARCHAR(3), 
  `rgb33` VARCHAR(3), 
  `rgb41` VARCHAR(3), 
  `rgb42` VARCHAR(3), 
  `rgb43` VARCHAR(3), 
  `rgb51` VARCHAR(3), 
  `rgb52` VARCHAR(3), 
  `rgb53` VARCHAR(3), 
  `rgb61` VARCHAR(3), 
  `rgb62` VARCHAR(3), 
  `rgb63` VARCHAR(3), 
  `rgb71` VARCHAR(3), 
  `rgb72` VARCHAR(3), 
  `rgb73` VARCHAR(3)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'setting'
#

INSERT INTO `setting` (`rgb11`, `rgb12`, `rgb13`, `rgb21`, `rgb22`, `rgb23`, `rgb31`, `rgb32`, `rgb33`, `rgb41`, `rgb42`, `rgb43`, `rgb51`, `rgb52`, `rgb53`, `rgb61`, `rgb62`, `rgb63`, `rgb71`, `rgb72`, `rgb73`) VALUES ('255', '250', '215', '225', '255', '215', '215', '245', '255', '245', '225', '210', '255', '233', '233', '238', '238', '238', '255', '233', '213');
# 1 records

#
# Table structure for table 'statusfix'
#

DROP TABLE IF EXISTS `statusfix`;

CREATE TABLE `statusfix` (
  `Sid` VARCHAR(3), 
  `Frun_id` VARCHAR(13), 
  `Sdate` DATETIME, 
  `Stime` VARCHAR(8), 
  `Sname` VARCHAR(20), 
  `Sday` VARCHAR(3), 
  `Sremark` VARCHAR(50), 
  `Suser` VARCHAR(30), 
  INDEX (`Frun_id`), 
  INDEX (`Sid`)
) ENGINE=myisam DEFAULT CHARSET=utf8;

SET autocommit=1;

#
# Dumping data for table 'statusfix'
#

INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('001', '5603-000022', '2013-03-13 00:00:00', '19:08', 'รอซ่อม', '', '', 'Administrator');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('001', 'SA6308-000001', '2020-08-04 00:00:00', '14:48', 'รอซ่อม', '', '', 'Administrator');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('001', 'SA6308-000002', '2020-08-04 00:00:00', '15:27', 'รอซ่อม', '', '', 'Administrator');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('002', 'SA6308-000002', '2020-08-05 00:00:00', '15:53', 'ซ่อมเสร็จแล้ว', '', '', 'กุ้ง');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('001', 'SA6308-000003', '2020-08-05 00:00:00', '15:57', 'รอซ่อม', '', '', 'กุ้ง');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('002', 'SA6308-000003', '2020-08-05 00:00:00', '16:00', 'คืนสินค้าแล้ว', '', 'เปลี่ยนพอร์ต USB', 'กุ้ง');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('003', 'SA6308-000002', '2020-08-05 00:00:00', '16:06', 'คืนสินค้าแล้ว', '', 'เปลี่ยนพอร์ต USB', 'กุ้ง');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('004', 'SA6308-000002', '2020-08-05 00:00:00', '16:40', 'รอซ่อม', '', '', 'Administrator');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('001', 'SA6308-000004', '2020-08-06 00:00:00', '16:22', 'รอซ่อม', '', '', 'Administrator');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('001', 'SA6406-000005', '2021-06-07 00:00:00', '15:16', 'รอซ่อม', '', '', 'Administrator');
INSERT INTO `statusfix` (`Sid`, `Frun_id`, `Sdate`, `Stime`, `Sname`, `Sday`, `Sremark`, `Suser`) VALUES ('002', 'SA6406-000005', '2021-06-07 00:00:00', '15:30', 'ซ่อมเสร็จแล้ว', '', '', 'กุ้ง');
# 11 records

