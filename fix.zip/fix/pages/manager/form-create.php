<?php 
    require_once('../authen.php'); 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>จัดการผู้ดูแลระบบ Icomservices</title>
    <link rel="shortcut icon" type="image/x-icon" href="../../assets/images/favicon.ico">
    <!-- stylesheet -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Kanit">
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="../../plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="../../assets/css/adminlte.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include_once('../includes/sidebar.php') ?>
        <div class="content-wrapper pt-3">
            <!-- Main content -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card shadow">
                                <div class="card-header border-0 pt-4">
                                    <h4>
                                        <i class="fas fa-user-cog"></i>
                                        เพิ่มข้อมูลผู้ดูแล
                                    </h4>
                                    <a href="./" class="btn btn-info my-3 ">
                                        <i class="fas fa-list"></i>
                                        กลับหน้าหลัก
                                    </a>
                                </div>
                                <form id="formData">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6 px-1 px-md-5">

                                                <div class="form-group">
                                                    <label for="emp_name">ชื่อ</label>
                                                    <input type="text" class="form-control" name="emp_name"
                                                        id="emp_name" placeholder="ชื่อ" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="emp_idcard">รหัสบัตรประชาชน</label>
                                                    <input type="number" class="form-control" name="emp_idcard"
                                                        id="emp_idcard" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==13) return false;"  placeholder="รหัสบัตรประชาชน" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="emp_username">ชื่อผู้ใช้งาน</label>
                                                    <input type="text" class="form-control" name="emp_username"
                                                        id="emp_username" placeholder="ชื่อผู้ใช้งาน" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="password">รหัสผ่าน</label>
                                                    <input type="password" class="form-control" name="emp_password"
                                                        id="emp_password" placeholder="รหัสผ่าน" required>
                                                </div>

                                            </div>
                                            <div class="col-md-6 px-1 px-md-5">
                                                <div class="form-group">
                                                    <label for="emp_address">ที่อยู่</label>
                                                    <input type="text" class="form-control" name="emp_address"
                                                        id="emp_address" placeholder="ที่อยู่" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="emp_tel">เบอร์โทรศัพท์</label>
                                                    <input type="number" class="form-control" name="emp_tel" id="emp_tel"
                                                        placeholder="เบอร์โทรศัพท์" pattern="/^-?\d+\.?\d*$/" onKeyPress="if(this.value.length==10) return false;"required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="emp_email">อีเมลล์</label>
                                                    <input type="email" class="form-control" name="emp_email"
                                                        id="emp_email" placeholder="อีเมลล์" required>
                                                </div>
                                                <div class="form-group">
                                                    <label for="permission">สิทธิ์การใช้งาน</label>
                                                    <select class="form-control" name="emp_status" id="permission"
                                                        required>
                                                        <option value disabled selected>กำหนดสิทธิ์</option>
                                                        <option value="admin">Administrator</option>
                                                        <option value="manager">Manager</option>
                                                        <option value="technician">Technician</option>
                                                        <option value="sales">Sales</option>
                                                        <option value="intern">Intern</option>
                                                        
                                                    </select>
                                                </div>

                                                <!-- <div class="form-group">
                                                <label for="customFile">รูปโปรไฟล์</label>
                                                <div class="custom-file">
                                                    <input type="file" class="custom-file-input" id="customFile" accept="image/*">
                                                    <label class="custom-file-label" for="customFile">เลือกรูปภาพ</label>
                                                </div>
                                            </div> -->

                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-block mx-auto w-50"
                                            name="submit">บันทึกข้อมูล</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once('../includes/footer.php') ?>
    </div>
    <!-- SCRIPTS -->
    <script src="../../plugins/jquery/jquery.min.js"></script>
    <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../../plugins/sweetalert2/sweetalert2.min.js"></script>
    <script src="../../assets/js/adminlte.min.js"></script>

    <script>
    $(function() {
        $('#formData').on('submit', function(e) {
            e.preventDefault();
            $.ajax({
                type: 'POST',
                url: '../../service/manager/create.php',
                data: $('#formData').serialize()
            }).done(function(resp) {
                Swal.fire({
                    text: 'เพิ่มข้อมูลเรียบร้อย',
                    icon: 'success',
                    confirmButtonText: 'ตกลง',
                }).then((result) => {
                    location.assign('./');
                });
            })
        });
    });
    </script>

</body>

</html>