<?php 
    /**
     * Page Manager
     * 
     * @link https://appzstory.dev
     * @author Yothin Sapsamran (Jame AppzStory Studio)
     */
    require_once('../authen.php'); 
    require_once '../../service/connect.php'; 
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> รายการสั่งซื้อใหม่ </title>
    <link rel="shortcut icon" type="image/x-icon" href="../../assets/images/favicon.ico">

    <!-- stylesheet -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Kanit">
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="../../plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="../../plugins/select2/css/select2.min.css">
    <link rel="stylesheet" href="../../assets/css/adminlte.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">

    <!-- Datatables -->
    <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">

    <!-- jquery.Thailand -->
    <link rel="stylesheet"
        href="https://earthchie.github.io/jquery.Thailand.js/jquery.Thailand.js/dist/jquery.Thailand.min.css">
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include_once('../includes/sidebar.php') ?>
        <div class="content-wrapper pt-4">
            <!-- Main content -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card shadow">
                                <div class="card-header border-0 pt-4">
                                    <h4>
                                        <i class="fas fa-cart-arrow-down"></i>
                                        รายการสั่งซื้อใหม่
                                    </h4>
                                </div>
                                <form id="formData">
                                <div class="card-body px-1 px-md-5">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="card shadow-sm">
                                                <div class="card-header pt-4">
                                                    <h3 class="card-title">
                                                        <i class="fas fa-user"></i>
                                                        ข้อมูลลูกค้า
                                                    </h3>
                                                </div>
                                                <div class="card-body px-5">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <?php  $stmt = $conn->query("SELECT * FROM customers");
                                                    ?>
                                                            <div class="form-group">
                                                                <label>ค้นหารายชื่อหน่วยงาน/สถานที่</label>
                                                                <select class="custom-select selectSearch"
                                                                    name="cus_name" id="cus_name"
                                                                    data-placeholder="ค้นหาชื่อสถานที่" required>
                                                                    <option selected="selected">
                                                                    <option> <?php While($row = $stmt->fetch()){?>
                                                                    <option><?php echo $row['Tcus']?></option>
                                                                    <?php }?>
                                                                </select>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="nameorphone">ชื่อ/เบอร์</label>
                                                                <input type="text"
                                                                    class="form-control form-control-border"
                                                                    name="nameorphone" id="nameorphone"
                                                                    placeholder="ชื่อ/เบอร์">
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="card shadow-sm">
                                                <div class="card-header pt-4">
                                                    <h3 class="card-title">
                                                        <i class="fas fa-user"></i>
                                                        ข้อมูลพนักงาน
                                                    </h3>
                                                </div>
                                                <div class="card-body px-5">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <?php  $stmt = $conn->query("SELECT * FROM employee ");
                                                    ?>
                                                            <div class="form-group">
                                                                <label>ชื่อพนักงานที่รับผิดชอบ</label>
                                                                <select class="custom-select selectSearch" name="emp_id"
                                                                    id="emp_id" data-placeholder="ค้นหาชื่อสถานที่" required>
                                                                    <option selected="selected">
                                                                    <option> <?php While($row = $stmt->fetch()){?>
                                                                    <option value="<?php echo $row['emp_id']?>"><?php echo $row['emp_name']?></option>
                                                                    <?php }?>
                                                                </select>
                                                            </div>


                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                        <div class="col-lg-6">
                                            <div class="card shadow-sm">
                                                <div class="card-header pt-4">
                                                    <h3 class="card-title">
                                                        <i class="fas fa-user"></i>
                                                        รายการสินค้า
                                                    </h3>
                                                </div>
                                                <div class="card-body px-5">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <div class="form-group">
                                                                <label for="order_productlist">รายการ</label>
                                                                <input type="text"
                                                                    class="form-control form-control-border"
                                                                    name="order_productlist" id="order_productlist"
                                                                    placeholder="ชื่อสินค้า" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="order_qty">จำนวน</label>
                                                                <input type="number"
                                                                    class="form-control form-control-border"
                                                                    name="order_qty" id="order_qty"
                                                                    placeholder="จำนวน/ชิ้น" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="order_link">ลิ้งสินค้า</label>
                                                                <input type="text"
                                                                    class="form-control form-control-border"
                                                                    name="order_link" id="order_link"
                                                                    placeholder="ลิ้งสินค้า" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="order_comment">หมายเหตุ</label>
                                                                <textarea placeholder="ลิ้งสินค้า"
                                                                    class="form-control form-control-border"
                                                                   name="order_comment" id="order_comment" rows="3"></textarea>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>สถานะ</label>
                                                                <select class="custom-select selectSearch"
                                                                    name="order_status" id="order_status"
                                                                    data-placeholder="สถานะ" required>
                                                                    <option selected="selected">
                                                                    <option value="ยังไม่ดำเนินการ">ยังไม่ดำเนินการ</option>
                                                                    <option value="ลูกค้าอนุมัติ">ลูกค้าอนุมัติ</option>
                                                                    <option value="ลูกค้าไม่อนุมัติ">ลูกค้าไม่อนุมัติ</option>
                                                                    <option value="สั่งสินค้าแล้ว">สั่งสินค้าแล้ว</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-block mx-auto w-50"
                                            name="submit">บันทึกข้อมูล</button>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include_once('../includes/footer.php') ?>
        </div>
        </div>
        
        <!-- scripts -->
        <script src="../../plugins/jquery/jquery.min.js"></script>
        <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../../plugins/sweetalert2/sweetalert2.min.js"></script>
        <script src="../../assets/js/adminlte.min.js"></script>
        <script src="../../plugins/select2/js/select2.full.min.js"></script>

        <!-- datatables -->
        <script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
        <script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

        <!-- jquery.Thailand -->
        <script type="text/javascript"
            src="https://earthchie.github.io/jquery.Thailand.js/jquery.Thailand.js/dist/jquery.Thailand.min.js">
        </script>
        <script type="text/javascript"
            src="https://earthchie.github.io/jquery.Thailand.js/jquery.Thailand.js/dependencies/JQL.min.js"></script>
        <script type="text/javascript"
            src="https://earthchie.github.io/jquery.Thailand.js/jquery.Thailand.js/dependencies/typeahead.bundle.js">
        </script>

        <script>
        $(function() {
            let products = $('#products tbody')
            let orders = $('#orders tbody')
            let arrOrders = []

            function selectSearch() {
                $('.selectSearch').select2({
                    width: '100%'
                })
            }


            function getProducts() {
                $.ajax({
                    type: "GET",
                    url: "../../service/products/"
                }).done(function(data) {
                    data.response.forEach(function(item, index) {
                        products.append(
                            `<tr>
                        <td> <img src="${item.p_image}" class="img-fluid" width="100px"> ${item.p_name} </td>
                        <td> ${item.price} </td>
                        <td> 
                            <button type="button" class="btn btn-outline-success" id="add${item.p_id}">
                                เลือกสินค้า
                            </button>
                        </td>
                    </tr>`)
                        $(`#add${item.p_id}`).on("click", function() {
                            addOrder(item)
                        })
                    })
                }).fail(function() {
                    products.append(`<tr><td colspan="5" class="text-center">ข้อมูลว่าง</td></tr>`)
                })
            }

            function addOrder(item) {
                item['p_amount'] = 1
                item['p_total'] = item['price']
                arrOrders.push(item)
                $('#modalAdd').modal('hide')
                renderOrder()
            }

            function deleteOrder(index) {
                arrOrders.splice(index, 1);
                renderOrder()
            }

            function renderOrder() {
                orders.empty();
                arrOrders.forEach(function(item, index) {
                    orders.append(`<tr>
                    <td> <a href="../products/" class="btn btn-outline-primary p-1"> ${item.p_id} </a> </td>
                    <td> <img src="${item.p_image}" class="w-150p d-block mx-auto"> </td>
                    <td> <p class="detail"> ${item.p_name}</p> </td>
                    <td> <input type="text" class="form-control rtl w-60p" value="${item.p_amount}"> </td>
                    <td> <p class="p-2 pl-4 text-right bg-light rounded-lg">${item.p_total}</p> </td>
                    <td> <input type="text" class="form-control rtl w-90p" value="0"> </td>
                    <td> <p class="p-2 pl-4 text-right bg-secondary rounded-lg">${item.price}</p> </td>
                    <td> 
                        <button type="button" class="btn btn-danger" id="delete${index}">
                            <i class="far fa-trash-alt"></i>
                        </button>
                    </td>
                </tr>`)
                    $(`#delete${index}`).on("click", function() {
                        deleteOrder(index)
                    })
                })
            }

            $('#formData').on('submit', function(e) {
                e.preventDefault()
                $.ajax({
                    type: 'POST',
                    url: '../../service/orders/create.php',
                    dataType: "json",
                    data: $('#formData').serialize()
                }).done(function(resp) {
                    Swal.fire({
                        text: 'เพิ่มข้อมูลเรียบร้อย',
                        icon: 'success',
                        confirmButtonText: 'ตกลง',
                    }).then((result) => {
                        location.assign('./')
                    })
                })
            })

            selectSearch()
            getProducts()

        })
        </script>
</body>

</html>