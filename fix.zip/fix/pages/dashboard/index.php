<?php 
    require_once('../authen.php');
    require_once('../../service/connect.php'); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>หน้าหลัก | ICOMSERVICES</title>
  <link rel="shortcut icon" type="image/x-icon" href="../../assets/images/favicon.ico">
  <!-- stylesheet -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Kanit">
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <link rel="stylesheet" href="../../assets/css/adminlte.min.css">
  <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php include_once('../includes/sidebar.php') ?>
    <div class="content-wrapper pt-3">
        <!-- Main content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-info shadow">
                            <div class="inner text-center">
                                <h1 class="py-3">&nbsp;ผู้ดูแลระบบ&nbsp;</h1>
                            </div>
                            <a href="../manager/" class="small-box-footer py-3"> คลิกจัดการระบบ <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-primary shadow">
                            <div class="inner text-center">
                                <h1 class="py-3">รายชื่อลูกค้า</h1>
                            </div>
                            <a href="../members/" class="small-box-footer py-3"> คลิกจัดการระบบ <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>

                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-success shadow">
                            <div class="inner text-center">
                                <h1 class="py-3">รายการซ่อมสินค้า</h1>
                            </div>
                            <a href="../products/" class="small-box-footer py-3"> คลิกจัดการระบบ <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-danger shadow">
                            <div class="inner text-center">
                                <h1 class="py-3">รายการสั่งซื้อ</h1>
                            </div>
                            <a href="../orders/" class="small-box-footer py-3"> คลิกจัดการระบบ <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <!-- <div class="col-lg-3">
                        <div class="small-box py-3 bg-white shadow">
                            <?php $sql1=$conn->query("SELECT COUNT(*) AS Counttotal FROM `fix` ");
                            $row1=$sql1->fetch();
                            
                            ?>
                            <div class="inner">
                                <h3><?php echo number_format($row1["Counttotal"]) ?> รายการ</h3>
                                <p class="text-danger">จำนวนเครื่องซ่อมทั้งหมด</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                        </div>
                    </div> -->
                    <!-- <div class="col-lg-3">
                        <div class="small-box py-3 bg-white shadow">
                        <?php 
                        $date=date('Y-m-d');
                        $sql2=$conn->query("SELECT COUNT(*) AS totaiaddtoday FROM `fix` WHERE `dtp_receive` LIKE '$date'");
                            $row2=$sql2->fetch();
                            ?>
                            <div class="inner">
                                <h3><?php echo number_format($row2["totaiaddtoday"]) ?> รายการ</h3>
                                <p class="text-danger">สรุปยอดรายการรับซ่อม วันนี้(<?php echo $date?>)</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                        </div>
                    </div> -->
                    <div class="col-lg-3">
                        <div class="small-box py-3 bg-white shadow">
                        <?php 
                        $datem=date('Y-m');
                        $sql3=$conn->query("SELECT COUNT(*) AS totaiaddtomonth FROM `fix` WHERE `dtp_receive` LIKE '%$datem%'");
                            $row3=$sql3->fetch();
                            ?>
                            <div class="inner">
                            <h3><?php echo number_format($row3["totaiaddtomonth"]) ?> รายการ</h3>
                                <p class="text-danger">สรุปยอดรายการรับซ่อม เดือนนี้(<?php echo $datem ?>)</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-lg-3">
                        <div class="small-box py-3 bg-white shadow">
                        <?php 
                        $datey=date('Y');
                        $sql4=$conn->query("SELECT COUNT(*) AS totaiaddtoyear FROM `fix` WHERE `dtp_receive` LIKE '%$datey%'");
                            $row4=$sql4->fetch();
                            ?>
                            <div class="inner">
                            <h3><?php echo number_format($row4["totaiaddtoyear"]) ?> รายการ</h3>
                                <p class="text-danger">สรุปยอดรายการรับซ่อม ปีนี้ (<?php echo $datey ?>)</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                        </div>
                    </div>
                </div> -->
                
                <!-- <div class="row">
                    <div class="col-lg-3">
                        <div class="small-box py-3 bg-white shadow">
                        <?php 
                        $sql5=$conn->query("SELECT COUNT(*) AS Totalreturn  FROM `fix` WHERE `Tstatus` LIKE 'คืนสินค้าแล้ว'");
                            $row5=$sql5->fetch();
                            ?>
                            <div class="inner">
                                <h3><?php echo number_format($row5["Totalreturn"]) ?> รายการ</h3>
                                <p class="text-danger">รายการคืนสินค้าทั้งหมด</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-chart-bar"></i>
                            </div>
                        </div>
                    </div> -->
                    <div class="col-lg-3">
                        <div class="small-box py-3 bg-white shadow">
                        <?php 
                        $sql6=$conn->query("SELECT COUNT(*) AS Totarepaired FROM `fix` WHERE `Tstatus` LIKE 'กำลังซ่อม'");
                            $row6=$sql6->fetch();
                            ?>
                            <div class="inner">
                            <h3><?php echo number_format($row6["Totarepaired"]) ?> รายการ</h3>
                                <p class="text-danger">รายการกำลังซ่อมสินค้าทั้งหมด</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-chart-area"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="small-box py-3 bg-white shadow">
                        <?php 
                        $sql7=$conn->query("SELECT COUNT(*) AS Totarepairesuccess FROM `fix` WHERE `Tstatus` LIKE 'ซ่อมเสร็จแล้ว'");
                            $row7=$sql7->fetch();
                            ?>
                            <div class="inner">
                            <h3><?php echo number_format($row7["Totarepairesuccess"]) ?> รายการ</h3>
                            <p class="text-danger">รายการซ่อมเสร็จแล้วทั้งหมด รอส่งคืน</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-cart-arrow-down"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="small-box py-3 bg-white shadow">
                        <?php 
                        $sql8=$conn->query("SELECT COUNT(*) AS Totareclaim FROM `fix` WHERE `Tstatus` LIKE 'รอเคลมอุปกรณ์'");
                            $row8=$sql8->fetch();
                            ?>
                            <div class="inner">
                            <h3><?php echo number_format($row8["Totareclaim"]) ?> รายการ</h3>
                            <p class="text-danger">รายการรอเครมสินค้าทั้งหมด</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card shadow">
                            <div class="card-body">
                                <div class="d-flex">
                                    <p class="d-flex flex-column">
                                        <span class="text-bold text-xl" id="salesReport"></span>
                                        <span class="text-danger" id="salesTextReport"></span>
                                    </p>
                                    <p class="ml-auto flex-row" id="salesbtn">
                                        <button class="btn btn-secondary m-1 d-block d-md-inline ml-auto" onclick="selectReport('report-month.php', this, 'line')">ยอดขายเดือนนี้</button>
                                        <button class="btn btn-outline-secondary m-1 d-block d-md-inline ml-auto" onclick="selectReport('report-sixmonths.php', this, 'bar')">6 เดือน</button>
                                        <button class="btn btn-outline-secondary m-1 d-block d-md-inline ml-auto" onclick="selectReport('report-twelvemonths.php', this, 'bar')">12 เดือน</button>
                                        <button class="btn btn-outline-secondary m-1 d-block d-md-inline ml-auto" onclick="selectReport('report-year.php', this, 'bar')">2021</button>
                                    </p>
                                </div>
                                <div class="position-relative">
                                    <canvas id="visitors-chart" height="350"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include_once('../includes/footer.php') ?>
</div>


<!-- SCRIPTS -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/adminlte.min.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="../../plugins/chart.js/Chart.min.js"></script>
<script src="../../plugins/chartjs-plugin-datalabels/dist/chartjs-plugin-datalabels.min.js"></script>
<script src="../../assets/js/pages/dashboard.js"></script>
</body>
</html>
