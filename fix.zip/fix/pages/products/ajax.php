<?php
                header('Content-Type: application/json');
                require_once('../../service/connect.php'); 
                
                $stmt = $conn->prepare("SELECT * FROM `customers` WHERE `Tcus` LIKE '%".$wordtest."%' ORDER BY `Tcus` DESC");
                   $stmt->execute();
                   $row = $stmt->fetchALL();
                   print_r($stmt);
                    $response = [
                        'status' => true,
                        'response' => $row,
                  
                        'message' => 'Get Data Orders Success'
                    ];
                 
                http_response_code(200);
                echo json_encode($response);
                
?>