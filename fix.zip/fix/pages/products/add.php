<?php

//add.php

require_once('../../service/connect.php'); 

if(isset($_POST["Tcus"]))
{
	$Tcus = preg_replace('/[^ก-๙A-Za-z0-9 _-]/s', '', $_POST["Tcus"]);

	$stmt = $conn->prepare("SELECT * FROM fix WHERE Tcus = '$Tcus'");
    $stmt->execute();
    $row = $stmt->fetch();

	$Taddressx= $row['Taddress'];
	$Ttelx = $row['Ttel'];
	$result = [
		'status' => true,
		'Taddressx' => $Taddressx,
		'Ttelx' => $Ttelx,
		'message' => "Get data Success"
	];
	http_response_code(200);
	//print_r($result);
	echo json_encode($result);
}

?>