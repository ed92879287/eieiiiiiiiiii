<?php 
    require_once('../authen.php');
    require_once('../../service/connect.php');
    
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>จัดการสินค้า Icomservices</title>
    <link rel="shortcut icon" type="image/x-icon" href="../../assets/images/favicon.ico">
    <!-- stylesheet -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Kanit">
    <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="../../plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="../../plugins/summernote/summernote-bs4.css">
    <link rel="stylesheet" href="../../assets/css/adminlte.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://raw.githack.com/ttskch/select2-bootstrap4-theme/master/dist/select2-bootstrap4.css"
        rel="stylesheet" />

</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <?php include_once('../includes/sidebar.php') ?>
        <div class="content-wrapper pt-3">
            <!-- Main content -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header border-0 pt-4">
                                    <h4>
                                        <i class="fas fa-shopping-cart"></i>
                                        เพิ่มข้อมูลสินค้า
                                    </h4>
                                    <a href="./" class="btn btn-info mt-3">
                                        <i class="fas fa-list"></i>
                                        กลับหน้าหลัก
                                    </a>
                                </div>
                                <form id="formData">
                                    <div class="card-body">
                                        <div class="form-row">
                                            <div class="container">
                                                <form action="page.cgi" method="post" name="form1">
                                                    <div class="form-group row mt-4">
                                                        <label for="repair"
                                                            class="col-md-3 col-lg-auto col-form-label">เลขที่ใบรับซ่อม</label>
                                                        <div class="col-md-9 col-lg-2" style="margin-left: -5px;">
                                                            <input type="text" class="form-control" id="" name="trn">
                                                        </div>
                                                        <label for="date"
                                                            class="col-md-3 col-lg-auto mt-sm-1 mt-lg-0 col-form-label">วันที่</label>
                                                        <div class="col-md-9 col-lg-2 mt-sm-1 mt-lg-0"
                                                            style="margin-left: -5px;">
                                                            <input type="text" class="form-control float-lg-left" id="dtp_receive"
                                                                name="dtp_receive" value="<?php echo date("d/m/Y"); ?>"
                                                                readonly>
                                                        </div>
                                                        <label for="pertran"
                                                            class="col-md-3 col-lg-auto mt-sm-1 mt-lg-0 col-form-label">ผู้ทำรายการ</label>
                                                        <div class="col-md-9 col-lg-2 mt-sm-1 mt-lg-0"
                                                            style="margin-left: -5px;">
                                                            <input type="text" class="form-control" id="Tuser" name="Tuser"
                                                                readonly value="<?php echo $_SESSION['AD_NAME']; ?>">
                                                        </div>
                                                        <?php
require_once('../../service/connect.php'); 
$query1 = "
  SELECT * FROM employee 
ORDER BY emp_name ASC
";

$result1 = $conn->query($query1);

?>
                                                        <label for="perrepair"
                                                            class="col-md-3 col-lg-auto mt-sm-1 mt-lg-0 col-form-label">ช่างผู้ซ่อม</label>
                                                        <div class="col-md-9 col-lg-2 mt-sm-1 mt-lg-0"
                                                            style="margin-left: -5px;">
                                                            <select class="form-control" name="Tuserfix" id="Tuserfix">
                                                                <option> </option>
                                                                <?php
            foreach($result1 as $row1)
            {
              echo '<option value="'.$row1['emp_name'].'">'.$row1['emp_name'].'</option>';
            }
            ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-12 mt-2 border-top">
                                                            <p class="font-weight-bold mt-1" style="font-size: 20px;">
                                                                ข้อมูลลูกค้า</p>
                                                            <div class="row">
                                                                <div class="col-md-2 col-lg-1">
                                                                    <label for="protype"
                                                                        class="col-form-label">ชื่อลูกค้า</label>
                                                                </div>
                                                                <?php
$query = "
  SELECT * FROM customers 
ORDER BY Tcus ASC
";

$result = $conn->query($query);

?>
                                                                <div class="col-md-10 col-lg-5 input-group-append">
                                                                    <select name="category" id="category"
                                                                        class="form-control form-control-lg select2">
                                                                        <option value=""></option>
                                                                        <?php
            foreach($result as $row)
            {
              echo '<option value="'.$row['Tcus'].'">'.$row['Tcus'].'</option>';
            }
            ?>
                                                                    </select>
                                                                </div>
                                                                <div class="col-md-2 col-lg-1">
                                                                    <label for="protype"
                                                                        class="col-form-label float-sm-left">โทรศัพท์</label>
                                                                </div>
                                                                <div class="col-md-10 col-lg-2">
                                                                    <input type="text"
                                                                        class="form-control float-sm-left" id="txtTtel"
                                                                        name="txtTtel">
                                                                </div>
                                                            </div>
                                                            <div class="row mt-1">
                                                                <div class="col-md-2  col-lg-1">
                                                                    <label for="protype"
                                                                        class="col-form-label">ที่อยู่</label>
                                                                </div>
                                                                <div class="col-md-10 col-lg-5">
                                                                    <input type="text"
                                                                        class="form-control float-lg-left mb-1"
                                                                        id="txtTaddress" name="txtTaddress">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-9 mt-4 border-top">
                                                            <p class="font-weight-bold mt-1" style="font-size: 20px;">
                                                                ข้อมูลสินค้า</p>
                                                            <div class="row">
                                                                <div class="col-md-3 col-lg-2">
                                                                    <label for="protype"
                                                                        class="col-form-label">ประเภทสินค้า</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-4">
                                                                    <input type="text"
                                                                        class="form-control float-lg-left" id="Tpro"
                                                                        name="Tpro">
                                                                </div>
                                                                <div class="col-md-3 col-lg-2 mt-sm-1 mt-lg-0">
                                                                    <label for="protype"
                                                                        class="col-form-label">ยี่ห้อสินค้า</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-4 mt-sm-1 mt-lg-0">
                                                                    <input type="text" class="form-control" id="Tbrand"
                                                                        name="Tbrand">
                                                                </div>
                                                            </div>
                                                            <div class="row mt-1">
                                                                <div class="col-md-3 col-lg-2">
                                                                    <label for="protype"
                                                                        class="col-form-label">รุ่นสินค้า</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-4">
                                                                    <input type="text" class="form-control" id="Tmodel"
                                                                        name="Tmodel">
                                                                </div>
                                                                <div class="col-md-3 col-lg-2 mt-sm-1 mt-lg-0">
                                                                    <label for="protype"
                                                                        class="col-form-label">สี</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-4 mt-sm-1 mt-lg-0">
                                                                    <input type="text" class="form-control" id="Tcolor"
                                                                        name="Tcolor">
                                                                </div>
                                                            </div>
                                                            <div class="row mt-1">
                                                                <div class="col-md-3 col-lg-2">
                                                                    <label for="protype" class="col-form-label">Serial
                                                                        Number</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-4 input-group-append">
                                                                <select  name="Tsn" id="Tsn"
                                                                        class="form-control form-control-lg select2" required>
                                                                        <option ></option>
                                                                        <?php
$query2 = "
  SELECT * FROM fix 
ORDER BY Tsn ASC
";

$result2 = $conn->query($query2);
                                                             
            foreach($result2 as $row2)
            {
              echo '<option value="'.$row2['Tsn'].'">'.$row2['Tsn'].'</option>';
            }
            ?>
                                                                    </select>
                                                                </div>
                                                                <div class="col-md-3 col-lg-2 mt-sm-1 mt-lg-0">
                                                                    <label for="protype"
                                                                        class="col-form-label">IMEI</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-4 mt-sm-1 mt-lg-0">
                                                                    <input type="text" class="form-control" id=""
                                                                        name="">
                                                                </div>
                                                            </div>
                                                            <div class="row mt-1">
                                                                <div class="col-md-3 col-lg-2">
                                                                    <label for="protype"
                                                                        class="col-form-label">สถานะรับประกัน</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-4">
                                                                    <input type="text" class="form-control" id=""
                                                                        name="">
                                                                </div>
                                                                <div class="col-md-3 col-lg-2 mt-sm-1 mt-lg-0">
                                                                    <label for="protype"
                                                                        class="col-form-label">หมดประกัน(ด/ป)</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-4 mt-sm-1 mt-lg-0">
                                                                    <input type="text" class="form-control" id=""
                                                                        name="" placeholder="__/__">
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                                                                    <label for="protype"
                                                                        class="col-form-label">การจัดเก็บข้อมูล</label>
                                                                </div>
                                                                <div
                                                                    class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0 input-group-append">
                                                                    <input type="text" class="form-control" id=""
                                                                        name="">
                                                                    <button class="btn btn-outline-secondary"
                                                                        type="button"><i
                                                                            class="fas fa-search"></i></button>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                                                                    <label for="protype"
                                                                        class="col-form-label">สภาพเครื่อง /
                                                                        ตำหนิ</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0">
                                                                    <input type="text" class="form-control" id=""
                                                                        name="">
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                                                                    <label for="protype"
                                                                        class="col-form-label">อาการเสีย</label>
                                                                </div>
                                                                <div
                                                                    class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0 input-group-append">
                                                                    <input type="text" class="form-control" id=""
                                                                        name="">
                                                                    <button class="btn btn-outline-secondary"
                                                                        type="button"><i
                                                                            class="fas fa-search"></i></button>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                                                                    <label for="protype"
                                                                        class="col-form-label">บันทึกเพิ่มเติม /
                                                                        อื่นๆ</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0">
                                                                    <textarea name="" id="" cols="30" rows="1"
                                                                        class="form-control"></textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12 col-lg-3 mt-4 pl-4 border-top">
                                                            <p class="font-weight-bold mt-1 mb-1"
                                                                style="font-size: 20px;">อุปกรณ์ที่นำมาด้วย</p>
                                                            <div class="row mt-1">
                                                                <div class="form-check col-6">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        id="defaultCheck1">
                                                                    <label class="form-check-label"
                                                                        for="defaultCheck1">สาย AC</label>
                                                                </div>
                                                                <div class="form-check col-6">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        value="" id="defaultCheck2">
                                                                    <label class="form-check-label"
                                                                        for="defaultCheck2">สาย Data link</label>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-1">
                                                                <div class="form-check col-6">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        value="" id="defaultCheck1">
                                                                    <label class="form-check-label"
                                                                        for="defaultCheck1">เมาส์</label>
                                                                </div>
                                                                <div class="form-check col-6">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        value="" id="defaultCheck2">
                                                                    <label class="form-check-label"
                                                                        for="defaultCheck2">สาย USB</label>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-1">
                                                                <div class="form-check col-6">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        value="" id="defaultCheck1">
                                                                    <label class="form-check-label"
                                                                        for="defaultCheck1">กระเป๋า</label>
                                                                </div>
                                                                <div class="form-check col-6">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        value="" id="defaultCheck2">
                                                                    <label class="form-check-label"
                                                                        for="defaultCheck2">Bluetooth</label>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-1">
                                                                <div class="form-check col-6">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        value="" id="defaultCheck1">
                                                                    <label class="form-check-label"
                                                                        for="defaultCheck1">Adapter</label>
                                                                </div>
                                                                <div class="form-check col-6">
                                                                    <input class="form-check-input" type="checkbox"
                                                                        value="" id="defaultCheck1">
                                                                    <label class="form-check-label"
                                                                        for="defaultCheck1">Memory Card</label>
                                                                </div>
                                                            </div>
                    
                                                            <div class="row mt-1">
                                                                <div class="col-md-3 col-lg-5">
                                                                    <label for="protype" class="col-form-label">อื่นๆ
                                                                        (ระบุ)</label>
                                                                </div>
                                                                <div class="col-md-9 col-lg-7">
                                                                    <input type="text" class="form-control" id="Tother"
                                                                        name="Tother">
                                                                </div>
                                                            </div>
                                                            <div class="mt-3 border-top">
                                                                <p class="font-weight-bold mt-1 mb-1"
                                                                    style="font-size: 20px;">ข้อมูลการบริการ</p>
                                                                <div class="row">
                                                                    <div class="col-md-3 col-lg-12">
                                                                        <label for="protype"
                                                                            class="col-form-label">ประเมินค่าซ่อม
                                                                            (บาท)</label>
                                                                    </div>
                                                                    <div class="col-md-9 col-lg-12">
                                                                        <input type="text" class="form-control" id=""
                                                                            name="">
                                                                    </div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                                                                        <label for="protype"
                                                                            class="col-form-label">วัน(นัด)รับสินค้า</label>
                                                                    </div>
                                                                    <div class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0">
                                                                        <input type="date" class="form-control " id=""
                                                                            name="">
                                                                    </div>
                                                                </div>
                                                                <div class="row mt-1">
                                                                    <div class="col-md-3 col-lg-6">
                                                                        <label for="protype"
                                                                            class="col-form-label">รับประกัน
                                                                            (วัน)</label>
                                                                    </div>
                                                                    <div class="col-md-9 col-lg-6">
                                                                        <input type="text" class="form-control" id=""
                                                                            name="">
                                                                    </div>
                                                                </div>
                                                                <div class="row mt-1">
                                                                    <div class="col-md-3 col-lg-6">
                                                                        <label for="protype"
                                                                            class="col-form-label">สิ้นสุดรับประกัน</label>
                                                                    </div>
                                                                    <div class="col-md-9 col-lg-6">
                                                                        <input type="text" class="form-control" id=""
                                                                            name="" value="" readonly>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="row">
                                                        <div class="col-md-7 col-lg-8 mt-2 mt-lg-2">
                                                            <button class="btn btn-primary mr-1 px-2"
                                                                type="submit">เพิ่ม</button>
                                                            <button class="btn btn-danger mr-1 px-2"
                                                                type="submit">ลบ</button>
                                                            <button class="btn btn-warning mr-1 px-2"
                                                                type="submit">แก้ไข</button>
                                                            <button class="btn btn-success mr-1 px-2"
                                                                type="submit">บันทึก</button>
                                                            <button class="btn btn-danger" type="submit">ยกเลิก</button>
                                                        </div>
                                                        <div class="col-md-5 col-lg-4 mt-2 mt-lg-2 clearfix">
                                                            <div class="float-md-right">
                                                                <button class="btn btn-primary mr-1"
                                                                    type="submit">พิมพ์ใบรับซ่อม</button>
                                                                <button class="btn btn-primary"
                                                                    type="submit">พิมพ์ใบคืนสินค้า</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-block mx-auto w-75"
                                            name="submit">บันทึกข้อมูล</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php include_once('../includes/footer.php') ?>
    </div>
    <!-- scripts -->
    <script src="../../plugins/jquery/jquery.min.js"></script>
    <script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../../plugins/sweetalert2/sweetalert2.min.js"></script>
    <script src="../../plugins/summernote/summernote-bs4.min.js"></script>
    <script src="../../assets/js/adminlte.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
    <!-- <script type="text/javascript">
    $(document).ready(function() {

        $("#Tcus").change(function() {
            $.ajax({
                url: "ajax_auto.php",
                type: "POST",
                data: 'Tcus=' + $("#Tcus").val(),
                success: function(row) {
                    if (row == '') {
                        $('input[type=text]').val('');
                    } else {
                        $.each(row, function(key, inval) {
                            $("#txtTcus").val(item.Tcus);
                            $("#txtTaddress").val(item.Taddress);
                            $("#txtTtel").val(item.Ttel);
                        });

                    }
                },
            })

        });
    });
    </script> -->
    <script>
    $(document).ready(function() {
        $('.select2').select2({
            placeholder: 'ชื่อลูกค้า หรือ สถานที่ ',
            theme: 'bootstrap4',
            tags: true,
        }).on('select2:close', function() {
            var element = $(this);
            var new_category = $.trim(element.val());
            if (new_category != '') {
                $.ajax({
                    url: "add.php",
                    type: "POST",
                    // dataType:"json",
                    // cache:false,
                    // processData:false,
                    data: {
                        Tcus: new_category
                    },
                    success: function(data) {
                        const obj = JSON.parse(data)
                        if (data == 'yes') {
                            element.append('<option value="' + new_category + '">' +
                                new_category + '</option>').val(new_category);
                        }
                                document.getElementById("txtTtel").value = obj.Ttelx;
                                document.getElementById("txtTaddress").value = obj.Taddressx;
                                // console.dir(JSON.stringify(obj.Ttelx));
                    }
                })
            }

        });

    });
    </script>

    <script>
    // $(function() {
    //     $('#detail').summernote({
    //         height: 300,
    //     });
    //     $('#formData').on('submit', function(e) {
    //         e.preventDefault();
    //         $.ajax({
    //             type: 'POST',
    //             url: '../../service/products/create.php',
    //             data: $('#formData').serialize()
    //         }).done(function(resp) {
    //             Swal.fire({
    //                 text: 'เพิ่มข้อมูลเรียบร้อย',
    //                 icon: 'success',
    //                 confirmButtonText: 'ตกลง',
    //             }).then((result) => {
    //                 location.assign('./');
    //             });
    //         })
    //     });
    // });
    </script>
</body>

</html>