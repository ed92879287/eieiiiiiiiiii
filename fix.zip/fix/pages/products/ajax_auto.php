<?php
header('Content-Type: application/json');
require_once('../../service/connect.php'); 

if(isset($_POST['Tcus']) != NULL){
    $stmt = $conn->prepare("SELECT * FROM `fix` WHERE `Tcus` LIKE '%".$_POST['Tcus']."%' ORDER BY `Tcus` DESC");
    $stmt->execute();
    $row = $stmt->fetchALL();
    print_r($stmt);
     $response = [
         'status' => true,
         'response' => $row,
   
         'message' => 'Get Data Orders Success'
     ];
     http_response_code(200);
echo json_encode($response);
}else{

}


 