<?php require_once("connect.php");
error_reporting(~E_NOTICE);?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
</head>

<body>
    <?php 
  
if($_POST['Tsn'] != NULL){
    print_r($_POST);
    $Tsn =$_POST['Tsn'];
    $sql=$conn->query("SELECT * FROM fix WHERE Tsn LIKE '%$Tsn%'");
$row=$sql->fetch_array();

}else{
}
?>
    <div class="container">
        <form action="page.cgi" method="post" name="form1">
            <div class="form-group row mt-4">
                <label for="repair" class="col-md-3 col-lg-auto col-form-label">เลขที่ใบรับซ่อม</label>
                <div class="col-md-9 col-lg-2" style="margin-left: -5px;">
                    <input type="text" class="form-control" id="" name="trn">
                </div>
                <label for="date" class="col-md-3 col-lg-auto mt-sm-1 mt-lg-0 col-form-label">วันที่</label>
                <div class="col-md-9 col-lg-2 mt-sm-1 mt-lg-0" style="margin-left: -5px;">
                    <input type="text" class="form-control float-lg-left" id="" name="dtp_receive"
                        value="<?php echo date("d/m/Y"); ?>" disabled>
                </div>
                <label for="pertran" class="col-md-3 col-lg-auto mt-sm-1 mt-lg-0 col-form-label">ผู้ทำรายการ</label>
                <div class="col-md-9 col-lg-2 mt-sm-1 mt-lg-0" style="margin-left: -5px;">
                    <input type="text" class="form-control" id="" name="" disabled>
                </div>
                <label for="perrepair" class="col-md-3 col-lg-auto mt-sm-1 mt-lg-0 col-form-label">ช่างผู้ซ่อม</label>
                <div class="col-md-9 col-lg-2 mt-sm-1 mt-lg-0" style="margin-left: -5px;">
                    <select class="form-control">
                        <option></option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-12 mt-2 border-top">
                    <p class="font-weight-bold mt-1" style="font-size: 20px;">ข้อมูลลูกค้า</p>
                    <div class="row">
                        <div class="col-md-2 col-lg-1">
                            <label for="protype" class="col-form-label">ชื่อลูกค้า</label>
                        </div>
                        <div class="col-md-10 col-lg-7 input-group-append">
                            <input type="text" class="form-control mb-1" id="" name="" value="<?php echo $row['Tcus']?>">
                            <button class="btn btn-outline-secondary float-lg-left mb-1" type="button"><i
                                    class="fas fa-search"></i></button>
                        </div>
                        <div class="col-md-2 col-lg-1">
                            <label for="protype" class="col-form-label" style="margin-right: 7px;">ผู้ติดต่อ</label>
                        </div>
                        <div class="col-md-10 col-lg-3">
                            <input type="text" class="form-control" id="" name="" >
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="col-md-2  col-lg-1">
                            <label for="protype" class="col-form-label">ที่อยู่</label>
                        </div>
                        <div class="col-md-10 col-lg-5">
                            <input type="text" class="form-control float-lg-left mb-1" id="" name="" value="<?php echo $row['Taddress']?>">
                        </div>
                        <div class="col-md-2 col-lg-1">
                            <label for="protype" class="col-form-label float-sm-left">โทรศัพท์</label>
                        </div>
                        <div class="col-md-10 col-lg-2">
                            <input type="text" class="form-control float-sm-left" id="" name="" value="<?php echo $row['Ttel']?>" >
                        </div>
                        <div class="col-md-2 col-lg-1 mt-sm-1 mt-lg-0">
                            <label for="protype" class="col-form-label float-sm-left">แฟกซ์</label>
                        </div>
                        <div class="col-md-10 col-lg-2 mt-sm-1 mt-lg-0">
                            <input type="text" class="form-control" id="" name="" style="width: 100%">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-lg-9 mt-4 border-top">
                    <p class="font-weight-bold mt-1" style="font-size: 20px;">ข้อมูลสินค้า</p>
                    <div class="row">
                        <div class="col-md-3 col-lg-2">
                            <label for="protype" class="col-form-label">ประเภทสินค้า</label>
                        </div>
                        <div class="col-md-9 col-lg-4">
                            <input type="text" class="form-control float-lg-left" id="" name="">
                        </div>
                        <div class="col-md-3 col-lg-2 mt-sm-1 mt-lg-0">
                            <label for="protype" class="col-form-label">ยี่ห้อสินค้า</label>
                        </div>
                        <div class="col-md-9 col-lg-4 mt-sm-1 mt-lg-0">
                            <input type="text" class="form-control" id="" name="">
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="col-md-3 col-lg-2">
                            <label for="protype" class="col-form-label">รุ่นสินค้า</label>
                        </div>
                        <div class="col-md-9 col-lg-4">
                            <input type="text" class="form-control" id="" name="">
                        </div>
                        <div class="col-md-3 col-lg-2 mt-sm-1 mt-lg-0">
                            <label for="protype" class="col-form-label">สี</label>
                        </div>
                        <div class="col-md-9 col-lg-4 mt-sm-1 mt-lg-0">
                            <input type="text" class="form-control" id="" name="">
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="col-md-3 col-lg-2">
                            <label for="protype" class="col-form-label">Serial Number</label>
                        </div>
                        <div class="col-md-9 col-lg-4 input-group-append">
                            <input type="number" class="form-control" id="Tsn" name="Tsn" value="<?php echo $row['Tsn']?>">
                            <button class="btn btn-outline-secondary float-lg-left mb-1" type="button"  
                                onClick="JavaScript:fncSubmit('page1')"><iclass="fas fa-search"></i></button>
                        </div>
                        <div class="col-md-3 col-lg-2 mt-sm-1 mt-lg-0">
                            <label for="protype" class="col-form-label">IMEI</label>
                        </div>
                        <div class="col-md-9 col-lg-4 mt-sm-1 mt-lg-0">
                            <input type="text" class="form-control" id="" name="">
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="col-md-3 col-lg-2">
                            <label for="protype" class="col-form-label">สถานะรับประกัน</label>
                        </div>
                        <div class="col-md-9 col-lg-4">
                            <input type="text" class="form-control" id="" name="">
                        </div>
                        <div class="col-md-3 col-lg-2 mt-sm-1 mt-lg-0">
                            <label for="protype" class="col-form-label">หมดประกัน(ด/ป)</label>
                        </div>
                        <div class="col-md-9 col-lg-4 mt-sm-1 mt-lg-0">
                            <input type="text" class="form-control" id="" name="" placeholder="__/__">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                            <label for="protype" class="col-form-label">การจัดเก็บข้อมูล</label>
                        </div>
                        <div class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0 input-group-append">
                            <input type="text" class="form-control" id="" name="">
                            <button class="btn btn-outline-secondary" type="button"><i
                                    class="fas fa-search"></i></button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                            <label for="protype" class="col-form-label">สภาพเครื่อง / ตำหนิ</label>
                        </div>
                        <div class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0">
                            <input type="text" class="form-control" id="" name="">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                            <label for="protype" class="col-form-label">อาการเสีย</label>
                        </div>
                        <div class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0 input-group-append">
                            <input type="text" class="form-control" id="" name="">
                            <button class="btn btn-outline-secondary" type="button"><i
                                    class="fas fa-search"></i></button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                            <label for="protype" class="col-form-label">บันทึกเพิ่มเติม / อื่นๆ</label>
                        </div>
                        <div class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0">
                            <textarea name="" id="" cols="30" rows="1" class="form-control"></textarea>
                        </div>
                    </div>
                </div>
                <div class="col-md-12 col-lg-3 mt-4 pl-4 border-top">
                    <p class="font-weight-bold mt-1 mb-1" style="font-size: 20px;">อุปกรณ์ที่นำมาด้วย</p>
                    <div class="row mt-1">
                        <div class="form-check col-6">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">สาย AC</label>
                        </div>
                        <div class="form-check col-6">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
                            <label class="form-check-label" for="defaultCheck2">สาย Data link</label>
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="form-check col-6">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">เมาส์</label>
                        </div>
                        <div class="form-check col-6">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
                            <label class="form-check-label" for="defaultCheck2">สาย USB</label>
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="form-check col-6">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">กระเป๋า</label>
                        </div>
                        <div class="form-check col-6">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
                            <label class="form-check-label" for="defaultCheck2">Bluetooth</label>
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="form-check col-6">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck1">
                            <label class="form-check-label" for="defaultCheck1">Adapter</label>
                        </div>
                        <div class="form-check col-6">
                            <input class="form-check-input" type="checkbox" value="" id="defaultCheck2">
                            <label class="form-check-label" for="defaultCheck2">อื่นๆ</label>
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="form-check col-md-3 col-lg-6">
                            <input class="form-check-input" style="margin-top: 12px" type="checkbox" value=""
                                id="defaultCheck2">
                            <label for="protype" class="col-form-label">Memory Card.</label>
                        </div>
                        <div class="col-md-9 col-lg-6">
                            <input type="text" class="form-control" id="" name="">
                        </div>
                    </div>
                    <div class="row mt-1">
                        <div class="col-md-3 col-lg-5">
                            <label for="protype" class="col-form-label">อื่นๆ (ระบุ)</label>
                        </div>
                        <div class="col-md-9 col-lg-7">
                            <input type="text" class="form-control" id="" name="">
                        </div>
                    </div>
                    <div class="mt-3 border-top">
                        <p class="font-weight-bold mt-1 mb-1" style="font-size: 20px;">ข้อมูลการบริการ</p>
                        <div class="row">
                            <div class="col-md-3 col-lg-12">
                                <label for="protype" class="col-form-label">ประเมินค่าซ่อม (บาท)</label>
                            </div>
                            <div class="col-md-9 col-lg-12">
                                <input type="text" class="form-control" id="" name="">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-3 col-lg-12 mt-sm-1 mt-lg-0">
                                <label for="protype" class="col-form-label">วัน(นัด)รับสินค้า</label>
                            </div>
                            <div class="col-md-9 col-lg-12 mt-sm-1 mt-lg-0">
                                <input type="date" class="form-control " id="" name="">
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-3 col-lg-6">
                                <label for="protype" class="col-form-label">รับประกัน (วัน)</label>
                            </div>
                            <div class="col-md-9 col-lg-6">
                                <input type="text" class="form-control" id="" name="">
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-3 col-lg-6">
                                <label for="protype" class="col-form-label">สิ้นสุดรับประกัน</label>
                            </div>
                            <div class="col-md-9 col-lg-6">
                                <input type="text" class="form-control" id="" name="" value="" disabled>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-7 col-lg-8 mt-2 mt-lg-2">
                    <button class="btn btn-primary mr-1 px-2" type="submit">เพิ่ม</button>
                    <button class="btn btn-danger mr-1 px-2" type="submit">ลบ</button>
                    <button class="btn btn-warning mr-1 px-2" type="submit">แก้ไข</button>
                    <button class="btn btn-success mr-1 px-2" type="submit">บันทึก</button>
                    <button class="btn btn-danger" type="submit">ยกเลิก</button>
                </div>
                <div class="col-md-5 col-lg-4 mt-2 mt-lg-2 clearfix">
                    <div class="float-md-right">
                        <button class="btn btn-primary mr-1" type="submit">พิมพ์ใบรับซ่อม</button>
                        <button class="btn btn-primary" type="submit">พิมพ์ใบคืนสินค้า</button>
                    </div>
                </div>
            </div>
        </form>


    </div>
</body>
<script language="javascript">
function fncSubmit(strPage) {
    if (strPage == "page1") {
        document.form1.action = "formcomshop.php?search=";
    }

    if (strPage == "page2") {
        document.form1.action = "page2.cgi";
    }

    document.form1.submit();
}
</script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
    integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
    integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
    integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
</script>

</html>